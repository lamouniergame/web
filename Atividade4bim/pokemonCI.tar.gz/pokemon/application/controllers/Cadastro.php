<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	class Cadastro extends CI_Controller {

	public function index(){
		$this->load->helper('form');		
		$this->load->view('cadastro_view');	
	}
	
	public function cadastrar(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('nome', 'Nome', 'required');
		$this->form_validation->set_rules('data', 'Data Captura', 'required');
		$this->form_validation->set_rules('tipo', 'Tipo Pokémon', 'required');
		if($this->form_validation->run() == FALSE){
			$this->index();		
		}
		else{
			$dados['Nome'] = $this->input->post('nome');
			$dados['Data_Captura'] = $this->input->post('data');
			$dados['Tipo_Pokemon'] = $this->input->post('tipo');
			$this->db->insert('pokemon',$dados);
			redirect(base_url('home'));
		}
	}
}