<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Consulta extends CI_Controller {

	public function __construct(){
        parent::__construct();
        $this->load->model("PokemonModel", "pokemonmodel");
        $this->pokemon = $this->pokemonmodel->imprimirPokemon();
    }
	
	public function index(){
		$this->load->helper('text');
		$dados['pokemon'] = $this->pokemon;		
		$this->load->view('consulta_view', $dados);	
	}
	
	public function deletar(){
		 $id = $this->uri->segment(3);		 
		 $this->load->model('pokemonmodel');
   	 $this->pokemonmodel->deletaPokemon($id);
  		 redirect(base_url('consulta')); 		
	}
	
	public function editar(){
		$this->load->helper('form');		
		$this->load->view('editar_view');	
	}
	
	public function edita_pokemon(){
		$id = $this->uri->segment(3);
		$tipo = $this->input->post('tipo');
		$this->pokemonmodel->editarPokemon($id, $tipo);
		redirect(base_url('consulta')); 	
	}
}