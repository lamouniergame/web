<?php
defined('BASEPATH') OR exit('No direct script access allowed');
  class PokemonModel extends CI_Model {
    public function __construct(){
      parent::__construct();
    }
    public function imprimirPokemon(){
      return $this->db->get('pokemon')->result();
    }
    
    public function deletaPokemon($id){
    	$this->db->where('id_pokemon', $id);
   	$this->db->delete('pokemon');
    }
    
    public function editarPokemon($id, $tipo){
    	$this->db->set('Tipo_Pokemon',$tipo);
      $this->db->where('id_pokemon',$id);
      $this->db->update('pokemon');
    }
}
?>