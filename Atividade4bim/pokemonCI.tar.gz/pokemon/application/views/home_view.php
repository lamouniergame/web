<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title>MENU</title>
	<link rel="stylesheet" type="text/css" href="http://localhost/pokemon/assets/css/home.css">
</head>
<style>
</style>
<body>
	<div id="container">	
		<div id="header">
			<?php
			if(null != $this->session->userdata('logado')) {
			}
			else{
				redirect(base_url("login"));
			}
			?>
		</div>
		<div id="menu">
		<img src="http://localhost/pokemon/assets/imagens/heyheyyouyou.png" class="img1">		
		<ul>		
			<li><?php echo anchor(base_url("cadastro") ,"Cadastrar Pokémon"); ?></li>
			<li><?php echo anchor(base_url("consulta") ,"Consultar Pokémon");	?></li>		
			<li style="float:right" class="active"><?php echo anchor(base_url("login/logout") ,"Sair"); ?></li>	
			<li style="float:right"><?php echo  "<a>"."Olá: " . $this->session->userdata('usuario')->login;"</a>" ?> </li>		
		</ul>
		</div>
	</div>
</body>
</html>
