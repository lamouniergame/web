<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title> CADASTRO DE POKÉMON </title>
	<link rel="stylesheet" type="text/css" href="http://localhost/pokemon/assets/css/cadastro.css">
	<link rel="stylesheet" type="text/css" href="http://localhost/pokemon/assets/css/consulta.css">
	<script src="<?php echo base_url('assets/js/jquery.mask.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/mask.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/jquery-3.1.1.min.js'); ?>"></script>
</head>
<body>
	<div id="header">
			<?php
			if(null != $this->session->userdata('logado')) {
			}
			else{
				redirect(base_url("login"));
			}
			?>
	</div>	
	<div id="container">		
		<?php echo "<div class=btnVoltar>" . anchor(base_url("home"),"Voltar") ."</div>" ?>			
		<img src="http://localhost/pokemon/assets/imagens/heyheyyouyou.png" class="img1">		
		<div class ="form-cadastro">
			<?php 
			$opcoes = array(
				'verde' => 'Verde',
				'laranja' => 'Laranja',
				'vermelho' => 'Vermelho',
			);			
			echo validation_errors();
			echo form_open(base_url('cadastro/cadastrar'),array('id'=>'cadastro')) .
			form_input(array('id'=>'nome', 'name'=>'nome','Placeholder'=>'Nome','value'=>set_value('nome'))) .
			form_input(array('id'=>'data', 'name'=>'data','Placeholder'=>'AAAA/MM/DD HH:MM','value'=>set_value('data'))) .
			form_dropdown('tipo', $opcoes, 'verde') .			
			form_submit("btnLogin","Cadastrar Pokémon") .
			form_close(); ?>
		</div>
	</div>
</body>
</html>
