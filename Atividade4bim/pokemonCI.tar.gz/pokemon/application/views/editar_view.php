<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title> EDITAR POKÉMON </title>
	<link rel="stylesheet" type="text/css" href="http://localhost/pokemon/assets/css/cadastro.css">
	<link rel="stylesheet" type="text/css" href="http://localhost/pokemon/assets/css/consulta.css">
	<script src="<?php echo base_url('assets/js/jquery.mask.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/mask.js'); ?>"></script>
</head>
<body>
	<div id="header">
			<?php
			if(null != $this->session->userdata('logado')) {
			}
			else{
				redirect(base_url("login"));
			}
			?>
	</div>	
	<div id="container">		
		<?php echo "<div class=btnVoltar>" . anchor(base_url("consulta"),"Voltar") ."</div>" ?>		
		<img src="http://localhost/pokemon/assets/imagens/heyheyyouyou.png" class="img1">		
		<div class="lista">
					<h3>Selecione um Tipo de Pokémon</h3>					
					<?php
						$opcoes = array(
							'verde' => 'Verde',
							'laranja' => 'Laranja',
							'vermelho' => 'Vermelho',
						);						
						$id = $this->uri->segment(3);
						echo form_open(base_url('consulta/edita_pokemon/'. $id),array('id'=>'cadastro')) .
							form_dropdown('tipo', $opcoes, 'verde') .			
							form_submit("btnLogin","Cadastrar Pokémon") .
							form_close(); ?>						
      </div>
	</div>
</body>
</html>