<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title>LOGIN</title>
	<link rel="stylesheet" type="text/css" href="http://localhost/pokemon/assets/css/login.css">
</head>
<body>
	<div id="container">
		<img src="http://localhost/pokemon/assets/imagens/heyheyyouyou.png" class="img1">		
		<p>Informe os dados de usuário e senha para fazer login no website.</p>
				
		<div class ="form-login">
			<?php echo validation_errors();
			echo form_open(base_url('login/logar'),array('id'=>'login')) .
			form_input(array('id'=>'login', 'name'=>'login','Placeholder'=>'Login','value'=>set_value('login'))) .
			form_password(array('id'=>'senha','name'=>'senha','Placeholder'=>'Senha')) .
			form_submit("btnLogin","Efetuar Login") .
			form_close(); ?>
		</div>
	</div>
</body>
</html>