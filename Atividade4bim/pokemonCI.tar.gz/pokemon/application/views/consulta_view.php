<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title> CONSULTA DE POKÉMON </title>
	<link rel="stylesheet" type="text/css" href="http://localhost/pokemon/assets/css/cadastro.css">
	<link rel="stylesheet" type="text/css" href="http://localhost/pokemon/assets/css/consulta.css">
	<script src="<?php echo base_url('assets/js/jquery.mask.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/mask.js'); ?>"></script>
</head>
<body>
	<div id="header">
			<?php
			if(null != $this->session->userdata('logado')) {
			}
			else{
				redirect(base_url("login"));
			}
			?>
	</div>	
	<div id="container">		
		<?php echo "<div class=btnVoltar>" . anchor(base_url("home"),"Voltar") ."</div>" ?>		
		<img src="http://localhost/pokemon/assets/imagens/heyheyyouyou.png" class="img1">		
		<table class="listinha">
    		<thead>
      		<tr>
        			<th>Nome</th>
        			<th>Tipo de Pokémon</th>
        			<th>Data de Captura</th>
					<th>Editar</th>					
					<th>Excluir</th>
     			</tr>
    		</thead>
    		<tbody>
				<tr class="lista">
					<?php
              	foreach($pokemon as $row){
               	echo "<tr>";
                  echo "<td>".$row->Nome."</td>";
                  echo "<td>".$row->Tipo_Pokemon."</td>";
                  echo "<td>".$row->Data_Captura."</td>";             
						echo "<div class=btnEdit>". "<td>" . anchor('../consulta/editar/'.$row->id_pokemon, 'Editar', 'id="$row->id_pokemon"')."</td>"."</div>";                  
                  echo "<div class=btnDel>". "<td>" . anchor('../consulta/deletar/'.$row->id_pokemon, 'Excluir', 'id="$row->id_pokemon"')."</td>"."</div>";
               }
               ?>
            </tr>
         </tbody>
      </table>
	</div>
</body>
</html>