<?php
//Feito por Vitor e Afonso
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('welcome_message');
	}
	public function referencia_nova()
	{
		$this->load->helper('form');
		$this->load->view('nova_referencia');
	}
	
	public function referencia_listagem()
	{
		$data['citacoes'] = $this->db->get('citacoes')->result();	
		$this->load->view('pdf', $data);
	}	
	
	public function nova_referencia(){
			$this->load->library('form_validation');
			$this->form_validation->set_rules('txt_nomeArquivo','Nome Arquivo','required');
			$this->form_validation->set_rules('txt_titulo','Título','required');
			$this->form_validation->set_rules('txt_autores','Autores','required');
			$this->form_validation->set_rules('txt_citacoes','Citações','required');
			$this->form_validation->set_rules('txt_referencias','Referencias','required');
			$this->form_validation->set_rules('txt_palavrasChave','Palavras Chave','required');			
			if($this->form_validation->run()){	
				$data ['nomeArquivo']=$this->input->post('txt_nomeArquivo');
				$data ['titulo']=$this->input->post('txt_titulo');
				$data ['autores']=$this->input->post('txt_autores');
				$data ['citacoes']=$this->input->post('txt_citacoes');
				$data ['referencias']=$this->input->post('txt_referencias');
				$data ['palavrasChave']=$this->input->post('txt_palavrasChave');
 				if($this->db->insert('citacoes', $data)){
 					redirect(base_url());
 				}else{
 					echo "Não foi possível gravar a referência no banco de dados.";
		 		}
		 	}else{
		 		$this->referencia_nova();	
		 	}
	}
}
