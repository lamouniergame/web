<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title>Sistema de Citações</title>
	<?php
 		echo link_tag('https://fonts.googleapis.com/css?family=Roboto+Condensed');
 		echo link_tag('assets/css/estilo.css');
 	?>
</head>
<body>
<div class="conteudo_nova">
<?php
	echo anchor(base_url("welcome/index"), "Início");
	echo '<div class="input">';
	echo "<p>Inserir Nova Referência";
	$atributos = array('name' => 'formulario_postagem', 'id'=>'formulario_postagem');
	echo form_open(base_url('welcome/nova_referencia'), $atributos).
	form_label("Nome do Arquivo:","txt_nomeArquivo").br().
 	form_input('txt_nomeArquivo').br().
 	form_label("Título:", "txt_titulo").br().
 	form_textarea('txt_titulo').br().
 	form_label("Autores:", "txt_autores").br().
 	form_textarea('txt_autores').br().
 	form_label("Citacoes:", "txt_citacoes").br().
 	form_textarea('txt_citacoes').br().
 	form_label("Referências:", "txt_referencias").br().
 	form_textarea('txt_referencias').br().
	form_label("Palavras Chave:", "txt_palavrasChave").br().
 	form_textarea('txt_palavrasChave').br().
 	form_submit("btn_enviar", "Cadastrar").
 	form_close();
 ?>
</div>
</div>
</body>
</html>