<?php
//Feito por Vitor e Afonso
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title>Sistema de Citações</title>
	<?php
 	  echo link_tag('https://fonts.googleapis.com/css?family=Roboto+Condensed');
 	  echo link_tag('assets/css/estilo.css');
 	?>
</head>
<body>
	<div class="conteudo">
	<?php
		echo anchor(base_url("welcome/referencia_nova"), "Cadastrar Nova Referência")."<br>".anchor(base_url("welcome/referencia_listagem"), "Listagem das Referências Cadastradas");
	?>
	</div>
</body>
</html>