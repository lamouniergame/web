<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title>Sistema de Citações</title>
	<?php
 		echo link_tag('https://fonts.googleapis.com/css?family=Roboto+Condensed');
 		echo link_tag('assets/css/estilo.css');
 	?>
</head>
<body>
	<?php
		foreach($citacoes as $post){
			echo "<h3>".$post->nomeArquivo."</h3>";
			echo "<h3>".$post->titulo."</h3>";
			echo "<h3>".$post->autores."</h3>";
			echo "<h3>".$post->citacoes."</h3>";
			echo "<h3>".$post->referencias."</h3>";
			echo "<h3>".$post->dataCadastro."</h3>";
			echo "<h3>".$post->palavrasChave."</h3>";		
		}
	?>
</body>
</html>