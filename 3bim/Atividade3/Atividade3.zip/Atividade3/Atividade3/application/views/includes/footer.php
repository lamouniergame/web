        <footer>
            <p>&copy; Copyright by Marcelo Mussel</p>
        </footer>
    </div>
</body>
</html>