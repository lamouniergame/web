<?php
	//Feito por Vitor e Afonso
	require('fpdf/fpdf.php');
	$pdf = new Fpdf('P', 'pt', 'A4');
	$pdf->SetTitle('Teste pdf 1');
	$pdf->SetAuthor('Vitor Melo & Afonso Vilhena');
	$pdf->SetCreator('php '.phpVersion());
	$pdf->SetKeywords('PHP', 'pdf');
	$pdf->SetSubject('Geração de Mala Direta');
	//Conteúdo
	$pdf->AddPage();
	//Relação
	$pdf->Ln(20);
	$pdf->SetFont('Times','',14);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetY(30);
	$pdf->SetX(180);
	$titulo='Relação das Referências Bibliográficas';
	$titulo=utf8_decode($titulo);
	$pdf->Write(30, $titulo);
	$laco = 0;
	foreach($citacoes as $row){	
	//Nome do arquivo
	$pdf->Ln(45);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetFont('Times','',14);
	$nomeArquivo="Nome do arquivo: ".$citacoes[$laco]->nomeArquivo;
	$nomeArquivo=utf8_decode($nomeArquivo);
	$pdf->Write(25,$nomeArquivo);
	//Título
	$pdf->Ln(30);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetFont('Times','',14);
	$titulo="Título: ".$citacoes[$laco]->titulo;
	$titulo=utf8_decode($titulo);
	$pdf->Write(25,$titulo);
	//Autores
	$pdf->Ln(30);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetFont('Times','',14);
	$autores="Autores: ".$citacoes[$laco]->autores;
	$autores=utf8_decode($autores);
	$pdf->Write(25,$autores);
	//Citações
	$pdf->Ln(30);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetFont('Times','',14);
	$cit="Citações: ".$citacoes[$laco]->citacoes;
	$cit=utf8_decode($cit);
	$pdf->Write(25,$cit);
	//Referencias
	$pdf->Ln(30);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetFont('Times','',14);
	$referencias="Referencias: ".$citacoes[$laco]->referencias;
	$referencias=utf8_decode($referencias);
	$pdf->Write(25,$referencias);	
	//PalavrasChave
	$pdf->Ln(30);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetFont('Times','',14);
	$chave="Palavras-chave: ".$citacoes[$laco]->palavrasChave;
	$chave=utf8_decode($chave);
	$pdf->Write(25,$chave);
	//Data de inclusão
	$pdf->Ln(30);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetFont('Times','',14);
	$data="Data de Inclusão: ".$citacoes[$laco]->dataCadastro;
	$data=utf8_decode($data);
	$pdf->Write(25,$data);
	//Linha 1
	$linha="------------------------------------------------------------------------------------------------------------------";
	$pdf->Write(30, $linha);	
	
	$laco = $laco + 1;	
	
	}$pdf->Output();
	
	
?>